package main;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class CallData {
	DefaultTableModel model = new practice().GetModel();
	JFileChooser fileopen = new JFileChooser();
	
	FileFilter filter = new FileNameExtensionFilter("Text/CSV file", "txt", "csv");
	
	fileopen.addChoosableFileFilter(filter);

	int ret = fileopen.showDialog(null, "Choose file");

}
