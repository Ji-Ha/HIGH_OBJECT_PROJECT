import javax.swing.JFrame;

public class ScoreCal extends JFrame {

	public ScoreCal() {

	}
}