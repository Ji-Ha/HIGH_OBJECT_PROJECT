import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ClassAvg {
	JFrame window = new JFrame();
	Student[] stu;
	int len;

	public ClassAvg(Student[] stu, int len) {
		window.setTitle("���� ��� ����");
		window.setLocation(20, 20);
		window.setSize(250, 150);

		JPanel p = new JPanel();
		JLabel o = new JLabel("�� ���������");
		p.add(o);

		JPanel s = new JPanel();
		JTextField score = new JTextField(10);
		score.setEnabled(false);
		JButton jb = new JButton("Ȯ��");

		s.add(score);
		s.add(jb);

		this.stu = stu;
		this.len = len;

		String[] option = { "�߰�����", "�⸻����", "����", "����", "��ǥ", "������", "������" };
		JPanel op = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JComboBox<String> cb = new JComboBox<>(option);
		cb.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JComboBox cb = (JComboBox) e.getSource();
				int index = cb.getSelectedIndex();
				int avg = 0;
				switch (index) {
				case 0:
					avg = getAvg("Mid");
					System.out.println(avg);
					score.setText(Integer.toString(avg));
					break;
				case 1:

					break;
				}
			}

			public int getAvg(String s) {
				int sum = 0;
				int avg = 0;
				System.out.print(stu[0].getMid());
				System.out.println(len);
				// for (int i = 0; stu.length; i++) {
				// // sum = sum + Integer.parseInt(stu[i].getMid());
				// }
				avg = sum / stu.length;
				return avg;
			}
		});
		op.add(cb);
		op.add(p);
		jb.addActionListener(l);
		window.add(op, BorderLayout.CENTER);
		window.add(s, BorderLayout.SOUTH);
		window.setVisible(true);

	}

	// �̺�Ʈ ����
	ActionListener l = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			{
				int total1 = 100;
				if (total1 != 100) {
					JOptionPane.showMessageDialog(null, "Total 100 ���� ����", "���� ����", JOptionPane.ERROR_MESSAGE);
				} else {
					window.dispose();
				}
			}
		}
	};
}