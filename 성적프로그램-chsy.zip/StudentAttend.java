
public class StudentAttend {
	String[] CheckAttend = new String[19];
}
