import javax.swing.JFrame;

public class searchStu extends JFrame {

	public searchStu() {
		setTitle("�׷���");
		setLocation(500, 200);
		setSize(590, 400);

		setVisible(true);
		setResizable(false);
	}

}
