
import java.awt.BorderLayout;

import javax.swing.JFrame;

//import EachGraph.scoreInsert;

public class NumGraph extends JFrame {
	static NumGraphPanel dp = new NumGraphPanel();
	static Student[] stu;
	static String s;
	static int stuNum;
	static int ID;

	public NumGraph() {
	};

	public NumGraph(String s, Student[] stu, int stuNum) {
		this.s = s;
		this.ID = Integer.parseInt(s);
		this.stu = stu;
		this.stuNum = stuNum;
		setLocation(500, 200);
		setSize(900, 1000);
		add(dp, BorderLayout.CENTER);
		insert(s);
		setResizable(false);
		setVisible(true);
	}

	public static class scoreInsert {

		public static void insert(String s) {
			int num0 = 0;
			int num1 = 0;
			int num2 = 0;
			int num3 = 0;
			int num4 = 0;
			int num5 = 0;
			int num6 = 0;
			int num7 = 0;
			int num8 = 0;
			int num9 = 0;

			int ID1 = 0;
			double score = 0;

			for (int i = 0; i < stuNum; i++) {
				score = Double.parseDouble(stu[i].getAll());
				System.out.print("������ ");
				System.out.println(score);
				ID1 = Integer.parseInt(stu[i].getStudentId());

				int sc = (int) (score - 1) / 10;

				if (sc == 10) {
					num0++;
				}
				int n = ID1 / 10000;

				System.out.println(n);
				if (n == ID) {
					switch (sc) {
					case 0:
						num0++;
						break;
					case 1:
						num1++;
						break;
					case 2:
						num2++;
						break;
					case 3:
						num3++;
						break;
					case 4:
						num4++;
						break;
					case 5:
						num5++;
						break;
					case 6:
						num6++;
						break;
					case 7:
						num7++;
						break;
					case 8:
						num8++;
						break;
					case 9:
						num9++;
						break;
					}
				}
			}
			dp.setNumbers(num0, num1, num2, num3, num4, num5, num6, num7, num8, num9);

		}
	}

	private void insert(String s) {
		scoreInsert.insert(s);
	}
}