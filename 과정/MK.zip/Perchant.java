import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Perchant extends SetGrade {

	JFrame window = new JFrame();
	static public double[] per = new double[8];

	/*
	 * class WindowHandler extends WindowAdapter { public void
	 * windowClosed(WindowEvent e) { System.out.println("windowClosed");
	 * window.dispose(); System.exit(0);
	 * 
	 * } }
	 */
	void show() {
		window.setTitle("�ݿ����� ���");
		window.setSize(430, 170);
		window.setLocation(20, 20);
		window.setVisible(true);

	}

	public Perchant() {
		per[0] = 0;
		// window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel p = new JPanel();
		JLabel o = new JLabel("�������� ����(%)");
		p.add(o);

		JPanel p1 = new JPanel();
		JPanel a = new JPanel();
		JLabel a1 = new JLabel("�߰�");
		JTextField a2 = new JTextField(5);
		a2.setText("" + 30);
		JPanel b = new JPanel();
		JLabel b1 = new JLabel("�⸻");
		JTextField b2 = new JTextField(5);
		b2.setText("" + 30);
		JPanel c = new JPanel();
		JLabel c1 = new JLabel("����");
		JTextField c2 = new JTextField(5);
		c2.setText("" + 5);
		JPanel d = new JPanel();
		JLabel d1 = new JLabel("����");
		JTextField d2 = new JTextField(5);
		d2.setText("" + 10);
		JPanel e = new JPanel();
		JLabel e1 = new JLabel("��ǥ");
		JTextField e2 = new JTextField(5);
		e2.setText("" + 5);
		JPanel f = new JPanel();
		JLabel f1 = new JLabel("������");
		JTextField f2 = new JTextField(5);
		f2.setText("" + 10);
		JPanel g = new JPanel();
		JLabel g1 = new JLabel("�⼮");
		JTextField g2 = new JTextField(5);
		g2.setText("" + 5);
		JPanel h = new JPanel();
		JLabel h1 = new JLabel("��Ÿ");
		JTextField h2 = new JTextField(5);
		h2.setText("" + 5);
		// �߰� �⸻ ���� ���� ��ǥ ������ �⼮ ��Ÿ
		JButton jb = new JButton("�������� �����Ϸ�");

		a.add(a1);
		a.add(a2);
		b.add(b1);
		b.add(b2);
		c.add(c1);
		c.add(c2);
		d.add(d1);
		d.add(d2);
		e.add(e1);
		e.add(e2);
		f.add(f1);
		f.add(f2);
		g.add(g1);
		g.add(g2);
		h.add(h1);
		h.add(h2);

		p1.add(a);
		p1.add(b);
		p1.add(c);
		p1.add(d);
		p1.add(e);
		p1.add(f);
		p1.add(g);
		p1.add(h);

		window.add(p1, BorderLayout.CENTER);
		window.add(p, BorderLayout.NORTH);
		window.add(jb, BorderLayout.SOUTH);
		// JPanel p1 = new JPanel();
		// ���ȭ ��Ű�����ؼ� �ʿ��Ѱ�.

		// �̺�Ʈ ����.

		ActionListener l = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					String min = a2.getText();
					String fin = b2.getText();
					String Sub = c2.getText();
					String Quz = d2.getText();
					String Pr = e2.getText();
					String Re = f2.getText();
					String Chul = g2.getText();
					String Pl = h2.getText();

					Double total1;
					total1 = Double.parseDouble(min) + Double.parseDouble(fin) + Double.parseDouble(Sub)
							+ Double.parseDouble(Quz) + Double.parseDouble(Pr) + Double.parseDouble(Re)
							+ Double.parseDouble(Chul) + Double.parseDouble(Pl);

					if (total1 != 100) {

						JOptionPane.showMessageDialog(null, "Total 100 ���� ����", "���� ����", JOptionPane.ERROR_MESSAGE);
					} else {

						per[0] = Double.parseDouble(min) / 100;
						per[1] = Double.parseDouble(fin) / 100;
						per[2] = Double.parseDouble(Sub) / 100;
						per[3] = Double.parseDouble(Quz) / 100;
						per[4] = Double.parseDouble(Pr) / 100;
						per[5] = Double.parseDouble(Re) / 100;
						per[6] = Double.parseDouble(Chul) / 100;
						per[7] = Double.parseDouble(Pl) / 100;

						window.dispose();
					}

				}

			}

		};

		jb.addActionListener(l);

	}

	public static void main(String[] args) throws SQLException {
		// show();
		new Perchant();
	}

}
//
// public class Perchant {
// public static void main(String[] args) {
// new PerchantDemo();
// }
// }
