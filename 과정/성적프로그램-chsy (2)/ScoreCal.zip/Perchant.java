import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Perchant extends JFrame {

	public Perchant() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("�ݿ����� ���");
		setLocation(20, 20);
		setSize(430, 170);

		JPanel p = new JPanel();
		JLabel o = new JLabel("�������� ����(%)");
		p.add(o);

		JPanel p1 = new JPanel();
		JPanel a = new JPanel();
		JLabel a1 = new JLabel("�߰�");
		JTextField a2 = new JTextField(5);
		JPanel b = new JPanel();
		JLabel b1 = new JLabel("�⸻");
		JTextField b2 = new JTextField(5);
		JPanel c = new JPanel();
		JLabel c1 = new JLabel("����");
		JTextField c2 = new JTextField(5);
		JPanel d = new JPanel();
		JLabel d1 = new JLabel("����");
		JTextField d2 = new JTextField(5);
		JPanel e = new JPanel();
		JLabel e1 = new JLabel("��ǥ");
		JTextField e2 = new JTextField(5);
		JPanel f = new JPanel();
		JLabel f1 = new JLabel("������");
		JTextField f2 = new JTextField(5);
		JPanel g = new JPanel();
		JLabel g1 = new JLabel("�⼮");
		JTextField g2 = new JTextField(5);
		JPanel h = new JPanel();
		JLabel h1 = new JLabel("��Ÿ");
		JTextField h2 = new JTextField(5);
		// �߰� �⸻ ���� ���� ��ǥ ������ �⼮ ��Ÿ
		JButton jb = new JButton("�������� �����Ϸ�");
		a.add(a1);
		a.add(a2);
		b.add(b1);
		b.add(b2);
		c.add(c1);
		c.add(c2);
		d.add(d1);
		d.add(d2);
		e.add(e1);
		e.add(e2);
		f.add(f1);
		f.add(f2);
		g.add(g1);
		g.add(g2);
		h.add(h1);
		h.add(h2);

		p1.add(a);
		p1.add(b);
		p1.add(c);
		p1.add(d);
		p1.add(e);
		p1.add(f);
		p1.add(g);
		p1.add(h);

		add(p1, BorderLayout.CENTER);
		add(p, BorderLayout.NORTH);
		add(jb, BorderLayout.SOUTH);
		// JPanel p1 = new JPanel();

		setVisible(true);
	}
}