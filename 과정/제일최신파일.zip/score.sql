create database score;

use score;

create table person (
name varchar(20)



);