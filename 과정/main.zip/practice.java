package main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class practice extends JFrame {
	private JTable table;
	static Student[] stu = new Student[40];
	public double[] per = new double[8];
	//���������� ��¦ ������.
	private DefaultTableModel model;
	
	practice() {
		//���� ������ �ʿ䰡 ���� �� ������, �ʿ��ϴٸ� ����ϱ� �ٶ�.
		
	}
	
	private void run() {
		setTitle("�̿ϼ���ǰ�Դϴ�.");
		makeMenu();
		setSize(800, 345);
		setLocation(500, 280);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	void SetModel(DefaultTableModel m) {
		this.model = m;
	}
	
	public DefaultTableModel GetModel() {
		return model;
	}
	
//	void SetPercent(doub);
	
	
	void makeMenu() {
		table = new JTable();
		getContentPane().add(table);
		JMenuBar mb = new JMenuBar();
		JMenu m1 = new JMenu("����");
		JMenu m2 = new JMenu("����");
		JMenu m3 = new JMenu("���");
		JMenu m4 = new JMenu("�⼮");
		JMenu m5 = new JMenu("����");
		
		
		JMenuItem item = new JMenuItem("�ҷ�����");
		item.addActionListener(new MenuActionListener());
		m1.add(item);
		item = new JMenuItem("���� ����");
		item.addActionListener(new MenuActionListener());
		m1.add(item);
		item = new JMenuItem("DB�� ����");
		item.addActionListener(new MenuActionListener());
		m1.add(item);
		item = new JMenuItem("CSV�� ����");
		item.addActionListener(new MenuActionListener());
		m1.add(item);
	

		
		item = new JMenuItem("�������");
		item.addActionListener(new MenuActionListener());
		m2.add(item);
		item = new JMenuItem("�ݿ����� ����");
		item.addActionListener(new MenuActionListener());
		m2.add(item);
		item = new JMenuItem("��޼���");
		item.addActionListener(new MenuActionListener());
		m2.add(item);
		item = new JMenuItem("������� ���");
		item.addActionListener(new MenuActionListener());
		m2.add(item);
		item = new JMenuItem("������� ���");
		item.addActionListener(new MenuActionListener());
		m2.add(item);
		
		
		item = new JMenuItem("������ ������");
		item.addActionListener(new MenuActionListener());
		m3.add(item);
		JMenu m = new JMenu("�� ���� ������");
		item = new JMenuItem("�⼮����");
		item.addActionListener(new MenuActionListener());
		m.add(item);
		item = new JMenuItem("�߰���������");
		item.addActionListener(new MenuActionListener());
		m.add(item);
		item = new JMenuItem("�⸻��������");
		item.addActionListener(new MenuActionListener());
		m.add(item);
		item = new JMenuItem("��������");
		item.addActionListener(new MenuActionListener());
		m.add(item);
		item = new JMenuItem("��������");
		item.addActionListener(new MenuActionListener());
		m.add(item);
		item = new JMenuItem("��ǥ����");
		item.addActionListener(new MenuActionListener());
		m.add(item);
		item = new JMenuItem("����������");
		item.addActionListener(new MenuActionListener());
		m.add(item);
		item = new JMenuItem("��Ÿ����");
		item.addActionListener(new MenuActionListener());
		m.add(item);
		m3.add(m);
		mb.add(m3);
		
		item = new JMenuItem("�⼮ ��Ȳ");
		item.addActionListener(new MenuActionListener());
		m4.add(item);
		
		mb.add(m1); mb.add(m2); mb.add(m3); mb.add(m4);
		setJMenuBar(mb);
		
		
		
		// Table Model
			model = (DefaultTableModel)table.getModel();
			model.addColumn("name");
			model.addColumn("StudentId");
			model.addColumn("Mid");
			model.addColumn("Fin");
			model.addColumn("HW");
			model.addColumn("Quiz");
			model.addColumn("Pre");
			model.addColumn("Report");
			model.addColumn("Attend");
			model.addColumn("Another");
			model.addColumn("Total");
			model.addColumn("Rank");
			
			SetModel(model);

			// ScrollPane
			JScrollPane scroll = new JScrollPane(table);
			scroll.setBounds(100, 100, 600, 100);
			getContentPane().add(scroll);
			
	}
		

	public static void main(String[] args) {
		practice init = new practice();
		init.run();
	}
	
	class MenuActionListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			String cmd = e.getActionCommand();
			
			switch(cmd) {
			//�ؿ� ������ ���������� �����.
			//���������� ���α׷� ���ο��� �����͸� ������ �� �ʿ���. Ȥ�� �ٸ� �ǰ��� ������ �����ֱ� �ٶ�.
			case "�ҷ�����":
				System.out.println("�ҷ�����");
				//�̷��� �ϰ� ������ ������ ���� ������.
				//new CallData();
				JFileChooser fileopen = new JFileChooser();
				FileFilter filter = new FileNameExtensionFilter(
						"Text/CSV file", "txt", "csv");
				fileopen.addChoosableFileFilter(filter);

				int ret = fileopen.showDialog(null, "Choose file");

				if (ret == JFileChooser.APPROVE_OPTION) {

					// Read Text file
					File file = fileopen.getSelectedFile();

					try {
						BufferedReader br = new BufferedReader(new FileReader(
								file));
						String line;
						int row = 0;
						while ((line = br.readLine()) != null) {
							String[] arr = line.split(",");
							model.addRow(new Object[0]);
							model.setValueAt(arr[0], row, 0);
							model.setValueAt(arr[1], row, 1);
							model.setValueAt(arr[2], row, 2);
							model.setValueAt(arr[3], row, 3);
							model.setValueAt(arr[4], row, 4);
							model.setValueAt(arr[5], row, 5);
							model.setValueAt(arr[6], row, 6);
							model.setValueAt(arr[7], row, 7);
							model.setValueAt(arr[8], row, 8);
							model.setValueAt(arr[9], row, 9);
							row++;
						}
						br.close();
					} catch (IOException ex) {
						// TODO Auto-generated catch block
						ex.printStackTrace();
					}
				}

				break;
				
			case "DB�� ����":
				System.out.println("DB�� ����");
				Connection connect = null;
				Statement s = null;
				String url = "jdbc:mysql://localhost/score?characterEncoding=UTF-8&serverTimezone=UTC";
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					connect = DriverManager.getConnection(url,"root","12345");

					s = connect.createStatement();

					for(int i = 0; i<table.getRowCount();i++)
					{
						String name = table.getValueAt(i, 0).toString();
						String StudentId = table.getValueAt(i, 1).toString();
						String Attend = table.getValueAt(i,2).toString();
						String Total = table.getValueAt(i, 3).toString();
						String Mid = table.getValueAt(i, 4).toString();
						String Fin = table.getValueAt(i, 5).toString();
						String HW = table.getValueAt(i, 6).toString();
						String Quiz = table.getValueAt(i, 7).toString();
						String Pre = table.getValueAt(i, 8).toString();
						String Report = table.getValueAt(i, 9).toString();
						String Another = table.getValueAt(i, 10).toString();
						String Rank = table.getValueAt(i, 11).toString();

						// SQL Insert

						String sql = "INSERT INTO person (name, ID, attendance ,total ,middle, final, homework, quiz, announcement, report, other, rank_total) VALUES "
								+ "(" + "'" + name + "'," + StudentId + "," +  Attend + "," +  Total + "," +  Mid + ","
								+ Fin + "," + HW + "," + Quiz + "," +  Pre + "," +  Report + "," + Another + "," + Rank // + "," +  all
								+ ")";
						s.executeUpdate(sql);

					}

					JOptionPane.showMessageDialog(null,
							"Import Data Successfully");


				} catch (Exception ex) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, ex.getMessage());
					ex.printStackTrace();
				}


				try {
					if (s != null) {
						s.close();
						connect.close();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage());
					e1.printStackTrace();
				}
			
				break;
				
			case "CSV�� ����":
				System.out.println("CSV�� ����");
				connect = null;
				s = null;
				url = "jdbc:mysql://localhost/score?characterEncoding=UTF-8&serverTimezone=UTC";
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					connect = DriverManager.getConnection(url,"root","12345");

					s = connect.createStatement();
					//String sql = "SELECT * FROM score.person";

					ResultSet rec = s.executeQuery("SELECT * FROM score.person");

					String path = "C:\\Users\\user\\Desktop\\csv\\sample.csv";
					FileWriter writer;

					try {
						File file = new File(path);
						writer = new FileWriter(file,true);

						while((rec!=null)&&(rec.next())) {
							writer.write(rec.getString("name"));
							writer.write(",");
							writer.write(rec.getString("ID"));
							writer.write(",");
							writer.write(rec.getString("attendance"));
							writer.write(",");
							writer.write(rec.getString("total"));
							writer.write(",");
							writer.write(rec.getString("middle"));
							writer.write(",");
							writer.write(rec.getString("final"));
							writer.write(",");
							writer.write(rec.getString("homework"));
							writer.write(",");
							writer.write(rec.getString("quiz"));
							writer.write(",");
							writer.write(rec.getString("announcement"));
							writer.write(",");
							writer.write(rec.getString("report"));
							writer.write(",");
							writer.write(rec.getString("other"));
							writer.write(",");
							writer.write(rec.getString("rank_total"));
							writer.write("\n"); //\r\n
						}
						writer.flush();
						writer.close();

						System.out.println("Write success!");

					}catch(IOException e1) {
						//TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				// Close
				try {
					if(connect != null){
						s.close();
						connect.close();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
				break;
				
			case "���� ����":
				System.out.println("���� ����");
				connect = null;
				s = null;
				url = "jdbc:mysql://localhost/score?characterEncoding=UTF-8&serverTimezone=UTC";
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					connect = DriverManager.getConnection(url,"root","1234");

					s = connect.createStatement();

					for(int i = 0; i<table.getRowCount();i++)
					{
						stu[i] = new Student();
						stu[i].setName(table.getValueAt(i, 0).toString());
//						String StudentId = table.getValueAt(i, 1).toString();
//						String Mid = table.getValueAt(i,2).toString();
//						String Fin = table.getValueAt(i, 3).toString();
//						String HW = table.getValueAt(i, 4).toString();
//						String Quiz = table.getValueAt(i, 5).toString();
//						String Pre = table.getValueAt(i, 6).toString();
//						String Report = table.getValueAt(i, 7).toString();
//						String Attend = table.getValueAt(i, 8).toString();
//						String Another = table.getValueAt(i, 9).toString();
//						String Total = table.getValueAt(i, 10).toString();
//						String Rank = table.getValueAt(i, 11).toString();
//
//						// SQL Insert
//						
//						System.out.println(name + Mid);
						
//						String sql = "INSERT INTO person (name, StudentId, Mid ,Fin ,HW, Quiz, Pre, Report, Attend, Another, Total, Rank) VALUES "
//								+ "(" + "'" + name + "'," + StudentId + "," +  Mid + "," +  Fin + "," +  HW + ","
//								+ Quiz + "," + Pre + "," + Report + "," +  Attend + "," +  Another + "," + Total + "," + Rank// + "," +  all
//								+ ")";
//						System.out.println(sql);
//						s.executeUpdate(sql);

					}

					JOptionPane.showMessageDialog(null,
							"Import Data Successfully");


				} catch (Exception ex) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, ex.getMessage());
					ex.printStackTrace();
				}


				try {
					if (s != null) {
						s.close();
						connect.close();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage());
					e1.printStackTrace();
				}
				
				
				break;
			case "�������":
				System.out.println("�������");
				new ScoreCal();
				break;
			case "�ݿ����� ����":
				System.out.println("�ݿ����� ����");
				Perchant pc = new Perchant();
				pc.show();
				break;
			case "��޼���":
				System.out.println("��޼���");
				new SetGrade();
				break;
			case "�⼮ ��Ȳ":
				System.out.println("�⼮ ��Ȳ");
				new UCheck();
				break;
			case "������� ���":
				System.out.println("������� ���");
				new ClassAvg();
				break;
			case "������ ������":
				System.out.println("������ ������ ���");
				new TotalGraph();
				break;
			case "�⼮����":
				System.out.println("�⼮���� ���");
				// new EachGraph("attenance");
				break;
			case "�߰���������":
				System.out.println("�߰��������� ���");
				new EachGraph("middle");
				break;
			case "�⸻��������":
				System.out.println("�⸻�������� ���");
				new EachGraph("final");
				break;
			case "��������":
				System.out.println("�������� ���");
				new EachGraph("report");
				break;
			case "��������":
				System.out.println("�������� ���");
				new EachGraph("quiz");
				break;
			case "��ǥ����":
				System.out.println("��ǥ���� ���");
				new EachGraph("announcement");
				break;
			case "����������":
				System.out.println("���������� ���");
				new EachGraph("report");
				break;
			case "��Ÿ����":
				System.out.println("��Ÿ���� ���");
				new EachGraph("other");
				break;

			}
		}
		
	}

}
