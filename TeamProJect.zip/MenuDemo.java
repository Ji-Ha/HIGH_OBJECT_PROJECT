
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
//import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class MenuDemo extends Perchant {
	JFrame window = new JFrame();
	private JTable table;
	// private Frame
	static String Mid;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				MenuDemo form;
				try {
					form = new MenuDemo();
					form.window.setVisible(true);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	}

	public MenuDemo() throws SQLException {

		// Create Form Frame
		window.setTitle("����ó�� ���α׷�");
		window.setSize(800, 345);
		window.setLocation(500, 280);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// getContentPane().setLayout(null);

		// Table
		table = new JTable();
		window.getContentPane().add(table);

		// Table Model
		final DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.addColumn("name");
		model.addColumn("StudentId");
		model.addColumn("Mid");
		model.addColumn("Fin");
		model.addColumn("HW");
		model.addColumn("Quiz");
		model.addColumn("Pre");
		model.addColumn("Report");
		model.addColumn("Attend");
		model.addColumn("Another");
		model.addColumn("Total");
		model.addColumn("Rank");

		// ScrollPane
		JScrollPane scroll = new JScrollPane(table);
		scroll.setBounds(100, 100, 600, 100);
		window.getContentPane().add(scroll);

		// MenuBar
		JMenuBar mb = new JMenuBar();
		JMenu m1 = new JMenu("����");
		JMenu m2 = new JMenu("����");
		JMenu m3 = new JMenu("���");
		JMenu m4 = new JMenu("�⼮");
		JMenu m5 = new JMenu("����");

		// ���� ��ư
		JButton button = new JButton("�������");
		window.add(button, BorderLayout.SOUTH);

		// add menu in menubar
		mb.add(m1);
		mb.add(m2);
		mb.add(m3);
		mb.add(m4);
		mb.add(m5);

		// m1 menu.
		JMenuItem newItem, openItem, saveItem, csvItem;
		openItem = new JMenuItem("�ҷ�����");
		saveItem = new JMenuItem("DB�� ����");
		csvItem = new JMenuItem("CSV�� ����");

		m1.add(openItem);
		m1.add(saveItem);
		m1.add(csvItem);

		JMenuItem item;

		// execute
		item = new JMenuItem("�ݿ����� ����");
		item.addActionListener(l);
		m2.add(item);
		item = new JMenuItem("��޼���");
		item.addActionListener(l);
		m2.add(item);
		item = new JMenuItem("������� ���");
		item.addActionListener(l);
		m2.add(item);

		mb.add(m2);

		// ��� ����� ��
		item = new JMenuItem("������ ������");
		item.addActionListener(l);
		m3.add(item);
		m3.addActionListener(l);
		JMenu m = new JMenu("�� ���� ������");
		item = new JMenuItem("�⼮����");
		item.addActionListener(l);
		m.add(item);
		item = new JMenuItem("�߰���������");
		item.addActionListener(l);
		m.add(item);
		item = new JMenuItem("�⸻��������");
		item.addActionListener(l);
		m.add(item);
		item = new JMenuItem("��������");
		item.addActionListener(l);
		m.add(item);
		item = new JMenuItem("��������");
		item.addActionListener(l);
		m.add(item);
		item = new JMenuItem("��ǥ����");
		item.addActionListener(l);
		m.add(item);
		item = new JMenuItem("����������");
		item.addActionListener(l);
		m.add(item);
		item = new JMenuItem("��Ÿ����");
		item.addActionListener(l);
		m.add(item);
		m3.add(m);
		m3.addActionListener(l);

		mb.add(m3);

		item = new JMenuItem("�⼮ ��Ȳ");
		item.addActionListener(l);
		m4.add(item);
		mb.add(m4);

		// ����
		m5.add(new JMenuItem("��� ���� ����"));
		m5.add(new JMenuItem("��� ���� ����"));
		m5.add(new JMenuItem("�� ������ �ݿ� ���� ����"));
		m5.add(new JMenuItem("���� �ο� ����"));
		window.setJMenuBar(mb);

		// �ҷ�����
		openItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileopen = new JFileChooser();
				FileFilter filter = new FileNameExtensionFilter("Text/CSV file", "txt", "csv");
				fileopen.addChoosableFileFilter(filter);

				int ret = fileopen.showDialog(null, "Choose file");

				if (ret == JFileChooser.APPROVE_OPTION) {

					// Read Text file
					File file = fileopen.getSelectedFile();

					try {
						BufferedReader br = new BufferedReader(new FileReader(file));
						String line;
						int row = 0;
						while ((line = br.readLine()) != null) {
							String[] arr = line.split(",");
							model.addRow(new Object[0]);
							model.setValueAt(arr[0], row, 0);
							model.setValueAt(arr[1], row, 1);
							model.setValueAt(arr[2], row, 2);
							model.setValueAt(arr[3], row, 3);
							model.setValueAt(arr[4], row, 4);
							model.setValueAt(arr[5], row, 5);
							model.setValueAt(arr[6], row, 6);
							model.setValueAt(arr[7], row, 7);
							model.setValueAt(arr[8], row, 8);
							model.setValueAt(arr[9], row, 9);
							model.setValueAt(arr[10], row, 10);
							model.setValueAt(arr[11], row, 11);
							row++;

						}
						br.close();
					} catch (IOException ex) {
						// TODO Auto-generated catch block
						ex.printStackTrace();
					}
				}

			}
		});

		// DB�� �����ϱ�
		saveItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				Connection connect = null;
				Statement s = null;
				String url = "jdbc:mysql://localhost/score?characterEncoding=UTF-8&serverTimezone=UTC";
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					connect = DriverManager.getConnection(url, "root", "12345");

					s = connect.createStatement();

					for (int i = 0; i < table.getRowCount(); i++) {
						String name = table.getValueAt(i, 0).toString();
						String StudentId = table.getValueAt(i, 1).toString();
						Mid = table.getValueAt(i, 2).toString();
						String Fin = table.getValueAt(i, 3).toString();
						String HW = table.getValueAt(i, 4).toString();
						String Quiz = table.getValueAt(i, 5).toString();
						String Pre = table.getValueAt(i, 6).toString();
						String Report = table.getValueAt(i, 7).toString();
						String Attend = table.getValueAt(i, 8).toString();
						String Another = table.getValueAt(i, 9).toString();
						String Total = table.getValueAt(i, 10).toString();
						String Rank = table.getValueAt(i, 11).toString();

						// SQL Insert

						String sql = "INSERT INTO person (name, StudentId, Mid ,Fin ,HW, Quiz, Pre, Report, Attend, Another, Total, Rank) VALUES "
								+ "(" + "'" + name + "'," + StudentId + "," + Mid + "," + Fin + "," + HW + "," + Quiz
								+ "," + Pre + "," + Report + "," + Attend + "," + Another + "," + Total + "," + Rank // +
																														// ","
																														// +
																														// all
								+ ")";
						s.executeUpdate(sql);

					}

					JOptionPane.showMessageDialog(null, "Import Data Successfully");

				} catch (Exception ex) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, ex.getMessage());
					ex.printStackTrace();
				}

				try {
					if (s != null) {
						s.close();
						connect.close();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage());
					e1.printStackTrace();
				}
			}
		});

		button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				double[] all = new double[40];

				if (per[0] != 0) {
					for (int i = 0; i < 1; i++) {
						String min = Mid;
						// all[i] = Double.parseDouble(Mid) * per[0] + Double.parseDouble(Fin) *per[1]
						// + Double.parseDouble(HW) * per[2] + Double.parseDouble(Quiz) * per[3]
						// + Double.parseDouble(Pre) * per[4] + Double.parseDouble(Report) * per[5]
						// + Double.parseDouble(Attend) * per[6]
						// + Double.parseDouble(Another) * per[7];
						all[i] = Double.parseDouble(min) * per[0];
						// table.getValutAt(i,10)("" + all[i]);
						// T_Rank[i].setText("A");
						System.out.println(all[i]);
					}
				} else
					System.out.println("error");

			}
		});
		// CSV file����
		csvItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connect = null;
				Statement s = null;
				String url = "jdbc:mysql://localhost/score?characterEncoding=UTF-8&serverTimezone=UTC";
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					connect = DriverManager.getConnection(url, "root", "1234");

					s = connect.createStatement();

					ResultSet rec = s.executeQuery("SELECT * FROM score.person");

					String path = "C:\\Users\\user\\Desktop\\csv\\sample.csv";
					FileWriter writer;

					try {
						File file = new File(path);
						writer = new FileWriter(file, true);

						while ((rec != null) && (rec.next())) {
							writer.write(rec.getString("name"));
							writer.write(",");
							writer.write(rec.getString("studentId"));
							writer.write(",");
							writer.write(rec.getString("Mid"));
							writer.write(",");
							writer.write(rec.getString("Fin"));
							writer.write(",");
							writer.write(rec.getString("HW"));
							writer.write(",");
							writer.write(rec.getString("Quiz"));
							writer.write(",");
							writer.write(rec.getString("Pre"));
							writer.write(",");
							writer.write(rec.getString("Report"));
							writer.write(",");
							writer.write(rec.getString("Attend"));
							writer.write(",");
							writer.write(rec.getString("Another"));
							writer.write(",");
							writer.write(rec.getString("Total"));
							writer.write(",");
							writer.write(rec.getString("rank_total"));
							writer.write("\n"); // \r\n
						}
						writer.flush();
						writer.close();

						System.out.println("Write success!");

					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				// Close
				try {
					if (connect != null) {
						s.close();
						connect.close();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

	}

	ActionListener l = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JMenuItem mi = (JMenuItem) (e.getSource());
			switch (mi.getText()) {
			case "�������":
				System.out.println("�������");

				new ScoreCal();
				break;
			case "�ݿ����� ����":
				System.out.println("�ݿ����� ����");
				Perchant pc = new Perchant();
				pc.show();
				break;
			case "��޼���":
				System.out.println("��޼���");
				SetGrade sg = new SetGrade();
				sg.show();
				break;
			case "�⼮ ��Ȳ":
				System.out.println("�⼮ ��Ȳ");
				new UCheck();
				break;
			case "������� ���":
				System.out.println("������� ���");
				new ClassAvg();
				break;
			case "������ ������":
				System.out.println("������ ������ ���");
				new TotalGraph();
				break;
			case "�⼮����":
				System.out.println("�⼮���� ���");
				// new EachGraph("attenance");
				break;
			case "�߰���������":
				System.out.println("�߰��������� ���");
				new EachGraph("middle");
				break;
			case "�⸻��������":
				System.out.println("�⸻�������� ���");
				new EachGraph("final");
				break;
			case "��������":
				System.out.println("�������� ���");
				new EachGraph("report");
				break;
			case "��������":
				System.out.println("�������� ���");
				new EachGraph("quiz");
				break;
			case "��ǥ����":
				System.out.println("��ǥ���� ���");
				new EachGraph("announcement");
				break;
			case "����������":
				System.out.println("���������� ���");
				new EachGraph("report");
				break;
			case "��Ÿ����":
				System.out.println("��Ÿ���� ���");
				new EachGraph("other");
				break;

			}

		}
	};
}